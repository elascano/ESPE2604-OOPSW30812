class Pencil {
    constructor(id, color, length, brand){
        this.id = id;
        this.color = color;
        this.length = length;
        this.brand = brand;
    }

    toString() {
        return `Pencil ID: ${this.id}, Color: ${this.color}, Length: ${this.length} cm, Brand: ${this.brand}`;
    }
}

export default Pencil;