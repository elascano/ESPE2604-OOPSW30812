import Pencil from '../model/pencil.js'
import { writeFileSync, readFileSync } from 'fs';

let pencils = [];

function addPencil(id, color, length, brand) {
  const pencil = new Pencil(id, color, length, brand);
  pencils.push(pencil);
}

addPencil(1, 'Red', 15, 'Bic');
addPencil(2, 'Blue', 14, 'Faber-Castell');
addPencil(3, 'Black', 16, 'Staedtler');

writeFileSync('../file/pencils.json', JSON.stringify(pencils, null, 2));
console.log('Pencils written to pencils.json');

const data = readFileSync('../file/pencils.json', 'utf8');
const pencilsFromFile = JSON.parse(data).map(p => new Pencil(p.id, p.color, p.length, p.brand));
console.log('Pencils read from pencils.json:');

pencilsFromFile.forEach(p => console.log(p.toString()));