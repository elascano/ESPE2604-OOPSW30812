import sys
import os

# Ensure project root is in python path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from models.sorting_context import SortingContext
from models.database_manager import DatabaseManager
from views.sort_view import SortView
from controllers.sort_controller import SortController


def main():
    """
    Main entry point for the Strategy Pattern Sorting Application.
    """
    # Instantiate Model components
    context = SortingContext()
    db_manager = DatabaseManager()

    # Instantiate View component
    view = SortView()

    # Instantiate Controller component linking Model and View
    controller = SortController(view=view, context=context, db_manager=db_manager)

    # Launch GUI main event loop
    view.mainloop()


if __name__ == "__main__":
    main()
