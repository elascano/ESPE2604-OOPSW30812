from typing import List, Tuple
from .sorting_strategy import SortingStrategy, BubbleSort, InsertionSort, QuickSort


class SortingContext:
    """
    Context class for the Strategy Pattern (Fig. 5).
    Maintains a reference to a SortingStrategy object and encapsulates array size evaluation logic.
    """

    def __init__(self, strategy: SortingStrategy = None):
        self._strategy: SortingStrategy = strategy

    def set_sort_strategy(self, strategy: SortingStrategy) -> None:
        """
        Sets the concrete sorting strategy.
        """
        self._strategy = strategy

    def get_sort_strategy(self) -> SortingStrategy:
        return self._strategy

    def select_strategy_by_size(self, size: int) -> SortingStrategy:
        """
        Selects sorting strategy based on array size rules:
        - Size must be greater than 1.
        - 2 <= size <= 6: BubbleSort
        - 7 <= size <= 10: InsertionSort
        - size >= 11: QuickSort
        """
        if size <= 1:
            raise ValueError("Number of elements must be greater than 1.")
        
        if 2 <= size <= 6:
            strategy = BubbleSort()
        elif 7 <= size <= 10:
            strategy = InsertionSort()
        else:
            strategy = QuickSort()
            
        self.set_sort_strategy(strategy)
        return strategy

    def sort(self, data: List[int]) -> Tuple[List[int], str]:
        """
        Executes sorting using the selected strategy.
        Returns tuple of (sorted_data, strategy_name).
        """
        size = len(data)
        strategy = self.select_strategy_by_size(size)
        sorted_data = strategy.sort(data)
        return sorted_data, strategy.name
