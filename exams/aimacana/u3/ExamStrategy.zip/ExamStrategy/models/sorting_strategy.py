from abc import ABC, abstractmethod
from typing import List


class SortingStrategy(ABC):
    """
    Abstract Base Class for Sorting Strategies according to the Strategy Pattern.
    """

    @abstractmethod
    def sort(self, data: List[int]) -> List[int]:
        """
        Sorts a list of integers and returns the sorted list.
        """
        pass

    @property
    @abstractmethod
    def name(self) -> str:
        """
        Returns the formal name of the sorting algorithm.
        """
        pass


class BubbleSort(SortingStrategy):
    """
    ConcreteStrategyA: Bubble Sort Algorithm.
    Recommended for array sizes between 2 and 6 elements.
    """

    @property
    def name(self) -> str:
        return "BubbleSort"

    def sort(self, data: List[int]) -> List[int]:
        arr = list(data)
        n = len(arr)
        for i in range(n):
            swapped = False
            for j in range(0, n - i - 1):
                if arr[j] > arr[j + 1]:
                    arr[j], arr[j + 1] = arr[j + 1], arr[j]
                    swapped = True
            if not swapped:
                break
        return arr


class InsertionSort(SortingStrategy):
    """
    ConcreteStrategyC: Insertion Sort Algorithm.
    Recommended for array sizes between 7 and 10 elements.
    """

    @property
    def name(self) -> str:
        return "InsertionSort"

    def sort(self, data: List[int]) -> List[int]:
        arr = list(data)
        for i in range(1, len(arr)):
            key = arr[i]
            j = i - 1
            while j >= 0 and arr[j] > key:
                arr[j + 1] = arr[j]
                j -= 1
            arr[j + 1] = key
        return arr


class QuickSort(SortingStrategy):
    """
    ConcreteStrategyB: Quick Sort Algorithm.
    Recommended for array sizes of 11 elements or larger.
    """

    @property
    def name(self) -> str:
        return "QuickSort"

    def sort(self, data: List[int]) -> List[int]:
        arr = list(data)

        def _quick_sort(items: List[int]) -> List[int]:
            if len(items) <= 1:
                return items
            pivot = items[len(items) // 2]
            left = [x for x in items if x < pivot]
            middle = [x for x in items if x == pivot]
            right = [x for x in items if x > pivot]
            return _quick_sort(left) + middle + _quick_sort(right)

        return _quick_sort(arr)
