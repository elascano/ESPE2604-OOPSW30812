package ec.edu.espe.exame2;

import ec.edu.espe.exame2.model.*;

/**
 * Main class to demonstrate the UML diagram implementation
 * @author Anthony Aimacaña, MKA programer, @ESPE
 */
public class Exame2 {

    public static void main(String[] args) {
        // 1. Basic objects
        E e1 = new E();
        E e2 = new E();
        F f1 = new F();
        J j1 = new J();

        // 2. G implements H and depends on J
        G g = new G();

        // 3. Inheritance and A's recursive relationship
        A a = new A();
        a.addChild(new A());

        // 4. B (extends A, associated with H)
        B b = new B();
        b.addH(g);

        // 5. C (extends A, aggregation with E)
        C c = new C();
        c.addE(e1);
        c.addE(e2);

        // 6. D (extends A, aggregation with E, composition with F)
        D d = new D();
        d.addE(e1);
        d.addF(f1);

        // Show objects
        System.out.println(a);
        System.out.println(b);
        System.out.println(c);
        System.out.println(d);
        System.out.println(e1);
        System.out.println(f1);
        System.out.println(g);
        System.out.println(j1);
    }
}
