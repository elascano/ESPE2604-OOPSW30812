package ec.edu.espe.exame2.model;

import java.util.ArrayList;
import java.util.List;

/**
 * Class A (Base class with self-composition/aggregation)
 * @author Anthony Aimacaña, MKA programer, @ESPE
 */
public class A {
    private List<A> children = new ArrayList<>();

    public void addChild(A child) {
        children.add(child);
    }

    @Override
    public String toString() {
        return "A{childrenCount=" + children.size() + "}";
    }
}
