package ec.edu.espe.exame2.model;

import java.util.ArrayList;
import java.util.List;

/**
 * Class B extends A and has association with H
 * @author Anthony Aimacaña, MKA programer, @ESPE
 */
public class B extends A {
    private List<H> hs = new ArrayList<>();

    public void addH(H h) {
        hs.add(h);
    }

    @Override
    public String toString() {
        return "B{hs=" + hs + ", " + super.toString() + "}";
    }
}
