package ec.edu.espe.exame2.model;

import java.util.ArrayList;
import java.util.List;

/**
 * Class C extends A and has aggregation with E
 * @author Anthony Aimacaña, MKA programer, @ESPE
 */
public class C extends A {
    private List<E> es = new ArrayList<>();

    public void addE(E e) {
        if (es.size() < 3) { // 0..3 constraint
            es.add(e);
        }
    }

    @Override
    public String toString() {
        return "C{es=" + es + ", " + super.toString() + "}";
    }
}
