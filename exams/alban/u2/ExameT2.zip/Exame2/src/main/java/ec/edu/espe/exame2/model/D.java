package ec.edu.espe.exame2.model;

import java.util.ArrayList;
import java.util.List;

/**
 * Class D extends A, has aggregation with E and composition with F
 * @author Anthony Aimacaña, MKA programer, @ESPE
 */
public class D extends A {
    private List<E> es = new ArrayList<>(); // Aggregation
    private List<F> fs = new ArrayList<>(); // Composition

    public void addE(E e) {
        if (es.size() < 5) { // 0..5 constraint
            es.add(e);
        }
    }

    public void addF(F f) {
        fs.add(f);
    }

    @Override
    public String toString() {
        return "D{es=" + es + ", fs=" + fs + ", " + super.toString() + "}";
    }
}
