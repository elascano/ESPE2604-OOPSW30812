package ec.edu.espe.exame2.model;

/**
 * Class E
 * @author Anthony Aimacaña, MKA programer, @ESPE
 */
public class E {
    @Override
    public String toString() {
        return "E{}";
    }
}
