package ec.edu.espe.exame2.model;

/**
 * Class F
 * @author Anthony Aimacaña, MKA programer, @ESPE
 */
public class F {
    @Override
    public String toString() {
        return "F{}";
    }
}
