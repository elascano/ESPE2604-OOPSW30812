package ec.edu.espe.exame2.model;

/**
 * Class G implements H and depends on J
 * @author Anthony Aimacaña, MKA programer, @ESPE
 */
public class G implements H {
    @Override
    public void methodH() {
        System.out.println("Executing methodH in G");
    }

    public void useJ(J j) {
        System.out.println("G is using " + j);
    }

    @Override
    public String toString() {
        return "G{}";
    }
}
