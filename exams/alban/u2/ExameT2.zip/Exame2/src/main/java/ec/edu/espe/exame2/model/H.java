package ec.edu.espe.exame2.model;

/**
 * Interface H
 * @author Anthony Aimacaña, MKA programer, @ESPE
 */
public interface H {
    void methodH();
}
