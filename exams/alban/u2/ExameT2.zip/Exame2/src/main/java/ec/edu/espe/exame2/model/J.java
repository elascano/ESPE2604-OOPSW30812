package ec.edu.espe.exame2.model;

/**
 * Class J
 * @author Anthony Aimacaña, MKA programer, @ESPE
 */
public class J {
    @Override
    public String toString() {
        return "J{}";
    }
}
