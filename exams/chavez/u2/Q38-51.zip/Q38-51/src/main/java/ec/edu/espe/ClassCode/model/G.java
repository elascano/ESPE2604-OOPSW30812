/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ec.edu.espe.ClassCode.model;

/**
 *
 * @author Odalys Chavez, CodeBreakers, @ESPE
 */
public class G implements H{
    
    private J j;
        @Override
        public void method() {
            System.out.println("Operation in G");
    }
    public J getJ(){
        return j; 
    }
    public void setJ(J j){
        this.j = j; 
    }
    
}
