/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ec.edu.espe.ClassCode.model;

/**
 *
 * @author Odalys Chavez, CodeBreakers, @ESPE
 */
public class J {
    
}
