/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package ec.edu.espe.q3851;

/**
 *
 * @author Daniel Codena, CodeBreakers, @ESPE
 */
public class Q3851 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
