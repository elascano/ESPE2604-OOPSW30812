/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ec.edu.espe.q3851.model;

/**
 *
 * @author Daniel Codena, CodeBreakers, @ESPE
 */
public class F {
    D d;
}
