/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ec.edu.espe.q3851.model;

/**
 *
 * @author Daniel Codena, CodeBreakers, @ESPE
 */
public class G implements H{

    @Override
    public void method() {
        System.out.println("Hello");
    }
    
}
