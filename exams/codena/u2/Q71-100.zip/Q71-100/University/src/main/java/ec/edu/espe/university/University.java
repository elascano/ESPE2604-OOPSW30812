/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package ec.edu.espe.university;

import ec.edu.espe.university.view.FrmUniversity;

/**
 *
 * @author Daniel Codena, CodeBreakers, @ESPE
 */
public class University {

    public static void main(String[] args) {
        System.out.println("Hello World!");
        FrmUniversity frm = new FrmUniversity();
        frm.setVisible(true);
    }
}
