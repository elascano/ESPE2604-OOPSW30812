/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ec.edu.espe.q3851.model;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author Brandon Collahuazo,CodeBros,@ESPE
 */
public class A {
    
    private final List<A> subElementsA;

    public A() {
        this.subElementsA = new ArrayList<>();
    }


    public void addSubElementA() {
        this.subElementsA.add(new A()); 
    }

    public List<A> getSubElementsA() {
        return subElementsA;
    }
}