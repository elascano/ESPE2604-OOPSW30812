/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ec.edu.espe.q3851.model;

import java.util.ArrayList;
import java.util.List;


public class B extends A {
 
    private List<H> r; 

    public B(H firstH) {
        super();
        if (firstH == null) {
            throw new IllegalArgumentException("(1..*)");
        }
        this.r = new ArrayList<>();
        this.r.add(firstH);
    }

    public void addH(H newH) {
        if (newH != null) {
            this.r.add(newH);
        }
    }

    public List<H> getR() {
        return r;
    }
}