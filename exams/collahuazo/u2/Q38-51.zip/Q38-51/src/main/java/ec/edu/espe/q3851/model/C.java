/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ec.edu.espe.q3851.model;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Brandon Collahuazo,CodeBros,@ESPE
 */
public class C extends A {
 
    private List<E> listE;

    public C() {
        super();
        this.listE = new ArrayList<>();
    }


    public void addE(E objectE) {
        if (this.listE.size() < 3) {
            this.listE.add(objectE);
        } else {
            System.out.println("No add more of 3 elements");
        }
    }

    public List<E> getListE() {
        return listE;
    }
}
