/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package ec.edu.espe.q3851.model;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Brandon Collahuazo,CodeBros,@ESPE
 */

// D.java
public class D extends A {
   
    private List<E> aggregationE;

    private final List<F> compositionF;

    public D() {
        super();
        this.aggregationE = new ArrayList<>();
        this.compositionF = new ArrayList<>();
    }


    public void addE(E objectE) {
        if (this.aggregationE.size() < 5) {
            this.aggregationE.add(objectE);
        } else {
            System.out.println("max 5");
        }
    }


    public void createAndAddF() {
        F newF = new F(); 
        this.compositionF.add(newF);
    }

    public List<E> getAggregationE() { return aggregationE; }
    public List<F> getCompositionF() { return compositionF; }
}