from models.apartment import Apartment
from models.database import apartments_collection

class ApartmentController:
    def create_apartment(self, number, owner):
        apartment = Apartment(number, owner)
        apartments_collection.insert_one({
            "number": apartment.number,
            "owner": apartment.owner
        })
        return apartment
