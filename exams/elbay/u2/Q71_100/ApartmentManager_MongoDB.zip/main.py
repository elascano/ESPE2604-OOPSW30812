import tkinter as tk
from views.apartment_view import ApartmentView

def main():
    root = tk.Tk()
    ApartmentView(root)
    root.mainloop()

if __name__ == "__main__":
    main()
