class Apartment:
    def __init__(self, number, owner):
        self.number = number
        self.owner = owner
