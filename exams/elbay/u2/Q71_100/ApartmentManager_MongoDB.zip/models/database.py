from pymongo import MongoClient

MONGO_URI = "mongodb+srv://Didier:Didier12345@cluster0.jrfeap2.mongodb.net/?appName=Cluster0"
client = MongoClient(MONGO_URI)
db = client["ApartmentManager"]
apartments_collection = db["apartments"]
