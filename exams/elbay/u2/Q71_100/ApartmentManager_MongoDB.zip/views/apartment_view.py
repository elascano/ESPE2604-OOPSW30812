import tkinter as tk
from controllers.apartment_controller import ApartmentController

class ApartmentView:
    def __init__(self, root):
        self.controller = ApartmentController()
        root.title("Apartment Manager")

        tk.Label(root, text="Número").pack()
        self.number_entry = tk.Entry(root)
        self.number_entry.pack()

        tk.Label(root, text="Propietario").pack()
        self.owner_entry = tk.Entry(root)
        self.owner_entry.pack()

        tk.Button(root, text="Crear", command=self.create).pack()

        self.result = tk.Label(root, text="")
        self.result.pack()

    def create(self):
        apartment = self.controller.create_apartment(
            self.number_entry.get(),
            self.owner_entry.get()
        )
        self.result.config(
            text=f"Apartamento {apartment.number} - {apartment.owner}"
        )
