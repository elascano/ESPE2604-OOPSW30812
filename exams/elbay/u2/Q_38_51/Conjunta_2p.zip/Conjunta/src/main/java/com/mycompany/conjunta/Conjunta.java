/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.conjunta;

/**
 *
 * @author Didier Elbay  <Code_Bros , @ESPE>
 */
public class Conjunta {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
