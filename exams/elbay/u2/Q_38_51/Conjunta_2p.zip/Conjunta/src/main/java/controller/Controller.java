package controller;
import model.*;
import view.view; 

public class Controller {
    
    private view view; 
    
    
    public Controller(view v) { 
        this.view = v; 
    }
    
    public void run() {
        D d = new D();
        
        view.mostrar(d.saludar());
        
        G g = new G();
        g.ejecutar();
        
        
        view.mostrar("Sistema funcionando.");
    }
}