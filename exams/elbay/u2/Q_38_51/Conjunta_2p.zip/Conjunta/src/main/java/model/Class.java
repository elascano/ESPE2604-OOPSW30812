
package model;
 //@author Didier Elbay  <Code_Bros , @ESPE>
public class Class {}

interface H { void ejecutar(); }

class A { public String saludar() { return "Soy el padre A"; } }

class J { public void accionar() { System.out.println("J haciendo tareas"); } }

class F { public F() { System.out.println("F creado (Composición)"); } }

class E {}

class B extends A implements H { 
    public void ejecutar() { System.out.println("B ejecutando..."); } 
}

class C extends A { E[] e = new E[3]; }



