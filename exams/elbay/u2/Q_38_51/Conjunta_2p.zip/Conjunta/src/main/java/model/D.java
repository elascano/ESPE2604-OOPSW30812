package model;
public class D { public String saludar(){ return "Soy el padre A";} }