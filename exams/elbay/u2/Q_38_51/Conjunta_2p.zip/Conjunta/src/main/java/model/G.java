package model;
public class G { public void ejecutar(){ System.out.println("J haciendo tareas"); } }