/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package view;

/**
 *
 * @author Didier Elbay  <Code_Bros , @ESPE>
 */


public class view {
    public void mostrar(String mensaje) {
        System.out.println("Vista: " + mensaje);
    }
}
