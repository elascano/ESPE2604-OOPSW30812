const readlineSync = require("readline-sync");
const SortingContext = require("./SortingContext");
const BubbleSort = require("./strategies/BubbleSort");
const InsertionSort = require("./strategies/InsertionSort");
const QuickSort = require("./strategies/QuickSort");
const { saveResult, closeConnection } = require("./config/db");

function selectStrategy(size) {
  if (size >= 2 && size <= 6) {
    return { strategy: new BubbleSort(), name: "BubbleSort" };
  } else if (size >= 7 && size <= 10) {
    return { strategy: new InsertionSort(), name: "InsertionSort" };
  } else if (size >= 11) {
    return { strategy: new QuickSort(), name: "QuickSort" };
  }
  return null;
}

function parseInputArray(input) {
  return input
    .split(",")
    .map((value) => value.trim())
    .filter((value) => value.length > 0)
    .map((value) => Number(value));
}

function printTable(unsorted, sorted, algorithmName, size) {
  console.log("\n RESULTADOS ORGANIZADOS");
  console.log("Algorithm used : " + algorithmName);
  console.log("Array size     : " + size);
  console.log("Unsorted array : [" + unsorted.join(", ") + "]");
  console.log("Sorted array   : [" + sorted.join(", ") + "]");
  
}

async function main() {
  console.log("CODE FEST - Sorting Algorithms with Strategy Pattern");
  const input = readlineSync.question("Enter the elements separated by commas (e.g. 5,8,7,2): ");
  const unsortedArray = parseInputArray(input);
  const size = unsortedArray.length;

  if (size <= 1) {
    console.log("Error: the array size must be greater than 1.");
    return;
  }

  if (unsortedArray.some((value) => Number.isNaN(value))) {
    console.log("Error: the input contains invalid numbers.");
    return;
  }

  const selection = selectStrategy(size);
  const context = new SortingContext();
  context.setSortStrategy(selection.strategy);

  const sortedArray = context.sort(unsortedArray);

  printTable(unsortedArray, sortedArray, selection.name, size);

  const document = {
    unsorted: unsortedArray.join(","),
    size: size,
    sortAlgorithm: selection.name,
    sorted: sortedArray.join(",")
  };

  try {
    await saveResult(document);
    console.log("Result saved to MongoDB successfully.");
  } catch (error) {
    console.log("Error saving to MongoDB: " + error.message);
  } finally {
    await closeConnection();
  }
}

main();
