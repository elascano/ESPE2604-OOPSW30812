class SortingContext {
  constructor(strategy = null) {
    this.strategy = strategy;
  }

  setSortStrategy(strategy) {
    this.strategy = strategy;
  }

  sort(array) {
    if (!this.strategy) {
      throw new Error("No sorting strategy set");
    }
    return this.strategy.sort(array);
  }
}

module.exports = SortingContext;
