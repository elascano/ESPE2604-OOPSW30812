const { MongoClient } = require("mongodb");

const CONNECTION_STRING = "mongodb+srv://christopher:christopher171206@christopher.i75hlaj.mongodb.net/?appName=christopher";
const DATABASE_NAME = "strategyLastName";
const COLLECTION_NAME = "arrayFirstName";

let client = null;

async function connectToDatabase() {
  if (client) return client;
  client = new MongoClient(CONNECTION_STRING);
  await client.connect();
  return client;
}

async function saveResult(document) {
  const connectedClient = await connectToDatabase();
  const database = connectedClient.db(DATABASE_NAME);
  const collection = database.collection(COLLECTION_NAME);
  const result = await collection.insertOne(document);
  return result;
}

async function closeConnection() {
  if (client) {
    await client.close();
    client = null;
  }
}

module.exports = { saveResult, closeConnection };
