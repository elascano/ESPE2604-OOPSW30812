const SortingStrategy = require("./SortingStrategy");

class BubbleSort extends SortingStrategy {
  sort(array) {
    const result = [...array];
    const length = result.length;
    for (let i = 0; i < length - 1; i++) {
      for (let j = 0; j < length - 1 - i; j++) {
        if (result[j] > result[j + 1]) {
          const temp = result[j];
          result[j] = result[j + 1];
          result[j + 1] = temp;
        }
      }
    }
    return result;
  }
}

module.exports = BubbleSort;
