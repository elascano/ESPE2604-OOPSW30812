const SortingStrategy = require("./SortingStrategy");

class QuickSort extends SortingStrategy {
  sort(array) {
    const result = [...array];
    this.quickSortRecursive(result, 0, result.length - 1);
    return result;
  }

  quickSortRecursive(array, low, high) {
    if (low < high) {
      const pivotIndex = this.partition(array, low, high);
      this.quickSortRecursive(array, low, pivotIndex - 1);
      this.quickSortRecursive(array, pivotIndex + 1, high);
    }
  }

  partition(array, low, high) {
    const pivot = array[high];
    let i = low - 1;
    for (let j = low; j < high; j++) {
      if (array[j] <= pivot) {
        i++;
        const temp = array[i];
        array[i] = array[j];
        array[j] = temp;
      }
    }
    const temp = array[i + 1];
    array[i + 1] = array[high];
    array[high] = temp;
    return i + 1;
  }
}

module.exports = QuickSort;
