class SortingStrategy {
  sort(array) {
    throw new Error("Method sort() must be implemented");
  }
}

module.exports = SortingStrategy;
