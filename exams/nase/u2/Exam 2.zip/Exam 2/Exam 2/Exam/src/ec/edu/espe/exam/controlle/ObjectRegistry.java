/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ec.edu.espe.exam.controlle;
import java.util.ArrayList;
import java.util.List;
import ec.edu.espe.exam.model.A;
import ec.edu.espe.exam.model.E;

/**
 *
 * @author Jennyfer Nase
 */
public class ObjectRegistry {
    private List<A> masterListA;
    private List<E> masterListE;

    public ObjectRegistry() {
        this.masterListA = new ArrayList<>();
        this.masterListE = new ArrayList<>();
    }

    public void addA(A target) {
        masterListA.add(target);
    }

    public void addE(E target) {
        masterListE.add(target);
    }

    public void printAllRegistry() {
        System.out.println("\n--LIST--");
        System.out.println("--- Elemen A (A, B, C, D) ---");
        for (A obj : masterListA) {
            System.out.println(obj.toString());
        }
        System.out.println("\n--- Elemen Independ E ---");
        for (E obj : masterListE) {
            System.out.println(obj.toString());
        }
    }
}
