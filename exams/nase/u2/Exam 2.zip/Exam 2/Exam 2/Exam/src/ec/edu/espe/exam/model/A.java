/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ec.edu.espe.exam.model;

import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author Jennyfer Nase
 */
public class A {
    private String code;
    private List<A> subParts;

    public A(String code) {
        this.code = code;
        this.subParts = new ArrayList<>();
    }

    public String getCode() {
        return code;
    }

    public void addSubPart(A part) {
        if (part != null) {
            this.subParts.add(part);
        }
    }

    @Override
    public String toString() {
        return "A { code='" + code + "', subPartsCount=" + subParts.size() + " }";
    }
}
