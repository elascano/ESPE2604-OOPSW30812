/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ec.edu.espe.exam.model;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author Jennyfer Nase
 */
public class B extends A {
    private List<H> elementsH;

    public B(String code) {
        super(code); 
        this.elementsH = new ArrayList<>();
    }

    public void addH(H hElement) {
        if (hElement != null) {
            this.elementsH.add(hElement);
        }
    }

    @Override
    public String toString() {
        return "B (Hijo de A) { code='" + getCode() + "', asociadosH=" + elementsH.size() + " }";
    }
}