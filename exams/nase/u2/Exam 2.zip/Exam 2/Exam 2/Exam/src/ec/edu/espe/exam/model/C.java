/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ec.edu.espe.exam.model;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author Jennyfer Nase
 */
public class C extends A {
    private List<E> eList;

    public C(String code) {
        super(code);
        this.eList = new ArrayList<>();
    }

    public void aggregateE(E eObject) {
        this.eList.add(eObject);
    }

    @Override
    public String toString() {
        return "C (Hijo de A) { code='" + getCode() + "', agregadosE=" + eList.size() + " }";
    }
}