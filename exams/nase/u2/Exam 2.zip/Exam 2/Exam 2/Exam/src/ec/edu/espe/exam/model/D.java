/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ec.edu.espe.exam.model;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author Jennyfer Nase
 */
public class D extends A {
    private List<E> aggregatedE;
    private List<F> composedF;

    public D(String code) {
        super(code);
        this.aggregatedE = new ArrayList<>();
        this.composedF = new ArrayList<>();
    }

    public boolean aggregateE(E eObject) {
        if (aggregatedE.size() < 5) {
            aggregatedE.add(eObject);
            return true;
        } else {
            System.out.println("[!] Multiplicity limit reached: No more than 5 objects can be added E a D.");
            return false;
        }
    }
    public void composeF(String serial) {
        this.composedF.add(new F(serial));
    }
    @Override
    public String toString() {
        return "D (Hijo de A) { code='" + getCode() + "', agregadosE=" + aggregatedE.size() + "/5, compuestosF=" + composedF.size() + " }";
    }
}
