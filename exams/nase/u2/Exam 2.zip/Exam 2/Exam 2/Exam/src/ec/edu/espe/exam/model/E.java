/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ec.edu.espe.exam.model;

/**
 *
 * @author Jennyfer Nase
 */
public class E {
    private String label;

    public E(String label) {
        this.label = label;
    }
    @Override
    public String toString() {
        return "E { label='" + label + "' }";
    }
}
