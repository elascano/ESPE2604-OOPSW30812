/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ec.edu.espe.exam.model;

/**
 *
 * @author Jennyfer Nase
 */
public class F {
    private String serial;

    public F(String serial) {
        this.serial = serial;
    }

    @Override
    public String toString() {
        return "F { serial='" + serial + "' }";
    }
}
