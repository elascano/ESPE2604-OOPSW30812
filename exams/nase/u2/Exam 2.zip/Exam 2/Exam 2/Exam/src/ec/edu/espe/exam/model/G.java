/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ec.edu.espe.exam.model;

/**
 *
 * @author Jennyfer Nases
 */
public class G extends H {
    private String id;

    public G(String id) {
        this.id = id;
    }
    public void performAction() {
        System.out.println("-> Objeto G (" + id + ") ejecut  H.");
    }
    public void processDependency(J jObject) {
        System.out.println("-> G (" + id + ") deped: " + jObject.toString());
    }
    @Override
    public String toString() {
        return "G (Implementa H) { id='" + id + "' }";
    }
}
