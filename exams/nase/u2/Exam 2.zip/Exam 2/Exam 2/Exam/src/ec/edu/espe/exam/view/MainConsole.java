/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ec.edu.espe.exam.view;
import ec.edu.espe.exam.controlle.ObjectRegistry;
import ec.edu.espe.exam.model.*;
/**
 *
 * @author Jennyfer Nase
 */
public class MainConsole {

    public static void main(String[] args) {
        System.out.println("  STARTING ");

        ObjectRegistry registry = new ObjectRegistry();

        System.out.println(">>> 1. Interfaces and Dependencies:");
        G gObject = new G("G-01");
        J jObject = new J("J-Dependency-Obj");
        
        gObject.performAction(); 
        gObject.processDependency(jObject); 
        System.out.println();

        E e1 = new E("E-Alpha");
        E e2 = new E("E-Beta");
        E e3 = new E("E-Gamma");
        registry.addE(e1);
        registry.addE(e2);
        registry.addE(e3);

        A rootA = new A("A-Master");
        A subA = new A("A-SubPart");
        rootA.addSubPart(subA); 
        registry.addA(rootA);

        B classB = new B("B-Structural");
        registry.addA(classB);

        C classC = new C("C-Aggregate");
        classC.aggregateE(e1);
        classC.aggregateE(e2);
        registry.addA(classC);

        D classD = new D("D-Complex");
        
        classD.composeF("F-Serial-100");
        classD.composeF("F-Serial-200");

        classD.aggregateE(e1);
        classD.aggregateE(e2);
        classD.aggregateE(e3);
        classD.aggregateE(new E("E-Extra1"));
        classD.aggregateE(new E("E-Extra2"));
        classD.aggregateE(new E("E-Excedente")); 
        registry.addA(classD);

        registry.printAllRegistry();
        
        System.out.println(" COMPLETED ");
    }
}
