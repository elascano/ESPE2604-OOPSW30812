document.addEventListener('DOMContentLoaded', () => {
    const databaseInMemory = [];
    const view = new ShoeView();
    const app = new ShoeController(databaseInMemory, view);
});