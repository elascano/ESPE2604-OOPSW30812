class ShoeController {
    constructor(modelList, view) {
        this.shoesList = modelList;
        this.view = view;

        this.loadSampleData();

        this.view.bindAddShoe(() => this.handleCreate());
        this.view.bindDeleteShoe((id) => this.handleDelete(id));
        this.view.bindSearchShoe((id) => this.handleFindById(id));
        this.view.bindClearSearch(() => this.handleListAll());

        this.handleListAll();
    }

    loadSampleData() {
        this.shoesList.push(new Shoe("SH-1001", "Nike Air Max 270", 129.99, 25));
        this.shoesList.push(new Shoe("SH-1002", "Adidas Ultraboost 21", 180.00, 18));
        this.shoesList.push(new Shoe("SH-1003", "Puma Classic Suede", 65.00, 42));
    }

    handleListAll() {
        this.view.renderTable(this.shoesList);
        this.view.updateStatus(this.shoesList.length);
    }

    handleCreate() {
        const data = this.view.getFormData();

        if (this.shoesList.some(shoe => shoe.id.toLowerCase() === data.id.toLowerCase())) {
            alert("¡Error! Ya existe un zapato con ese Código ID.");
            return;
        }

        const newShoe = new Shoe(data.id, data.description, data.price, data.stock);
        this.shoesList.push(newShoe);
        
        this.view.clearForm();
        this.handleListAll();
    }

    handleDelete(id) {
        this.shoesList = this.shoesList.filter(shoe => shoe.id !== id);
        this.handleListAll();
    }

    handleFindById(id) {
        if (!id) {
            this.handleListAll();
            return;
        }
        const filtered = this.shoesList.filter(shoe => shoe.id.toLowerCase() === id.toLowerCase());
        this.view.renderTable(filtered);
    }
}