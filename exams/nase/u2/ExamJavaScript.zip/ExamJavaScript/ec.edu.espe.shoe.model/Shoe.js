class Shoe {
    constructor(id, description, price, stock) {
        this.id = id;
        this.description = description;
        this.price = Number(price);
        this.stock = Number(stock);
    }

    computeTotalValue() {
        return this.price * this.stock;
    }
}