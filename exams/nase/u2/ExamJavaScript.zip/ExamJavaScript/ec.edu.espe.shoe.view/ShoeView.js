class ShoeView {
    constructor() {
        // Mapeo exacto con los IDs de tu HTML original
        this.form = document.getElementById('form-shoe');
        this.tableBody = document.getElementById('tbl-body');
        this.statusLabel = document.getElementById('lbl-status');
        
        this.idInput = document.getElementById('input-id');
        this.descInput = document.getElementById('input-desc');
        this.priceInput = document.getElementById('input-price');
        this.stockInput = document.getElementById('input-stock');
        
        this.searchInput = document.getElementById('input-search');
        this.btnSearch = document.getElementById('btn-search');
        this.btnClear = document.getElementById('btn-clear');
    }

    renderTable(shoesArray) {
        this.tableBody.innerHTML = ''; 

        if (shoesArray.length === 0) {
            this.tableBody.innerHTML = `<tr><td colspan="6" style="text-align:center; color:gray;">No matching products found.</td></tr>`;
            return;
        }

        shoesArray.forEach(shoe => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td><b>${shoe.id}</b></td>
                <td>${shoe.description}</td>
                <td>$${shoe.price.toFixed(2)}</td>
                <td>${shoe.stock}</td>
                <td><b>$${shoe.computeTotalValue().toFixed(2)}</b></td>
                <td><button class="btn-delete" data-id="${shoe.id}">🗑 Delete</button></td>
            `;
            this.tableBody.appendChild(row);
        });
    }

    updateStatus(count) {
        this.statusLabel.textContent = `Total items listed: ${count}`;
    }

    getFormData() {
        return {
            id: this.idInput.value.trim(),
            description: this.descInput.value.trim(),
            price: this.priceInput.value,
            stock: this.stockInput.value
        };
    }

    clearForm() {
        this.form.reset();
        this.idInput.focus();
    }

    bindAddShoe(handler) {
        this.form.addEventListener('submit', (e) => {
            e.preventDefault();
            handler();
        });
    }

    bindDeleteShoe(handler) {
        this.tableBody.addEventListener('click', (e) => {
            if (e.target.classList.contains('btn-delete')) {
                const id = e.target.getAttribute('data-id');
                handler(id);
            }
        });
    }

    bindSearchShoe(handler) {
        this.btnSearch.addEventListener('click', () => {
            handler(this.searchInput.value.trim());
        });
    }

    bindClearSearch(handler) {
        this.btnClear.addEventListener('click', () => {
            this.searchInput.value = '';
            handler();
        });
    }
}