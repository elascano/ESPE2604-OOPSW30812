import json


class Picture:

    def __init__(self, id, brand, size, isDigital):

        self.id = id
        self.brand = brand
        self.size = size
        self.isDigital = isDigital

    def showInfo(self):

        print(
            self.id,
            self.brand,
            self.size,
            self.isDigital
        )

    def changeSize(self,
                   newSize):

        self.size = newSize

    def to_dict(self):

        return {

            "id": self.id,
            "brand": self.brand,
            "size": self.size,
            "isDigital": self.isDigital
        }


pictures = []


p1 = Picture(
    1,
    "Canon",
    "500px",
    True
)

p2 = Picture(
    2,
    "Sony",
    "300px",
    False
)

p3 = Picture(
    3,
    "Nikon",
    "700px",
    True
)


p2.changeSize("600px")


pictures.append(p1.to_dict())

pictures.append(p2.to_dict())

pictures.append(p3.to_dict())


p1.showInfo()

p2.showInfo()

p3.showInfo()


with open(
    "pictures.json",
    "w"
) as file:

    json.dump(
        pictures,
        file,
        indent=4
    )

print(
    "Data written to pictures.json"
)