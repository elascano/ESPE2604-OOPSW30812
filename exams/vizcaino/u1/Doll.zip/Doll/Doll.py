import json

class Doll:
    def __init__(self, id, brand, price, size):
        self.id = id
        self.brand = brand
        self.price = price
        self.size = size

    def to_dict(self):
        return {
            "id": self.id,
            "brand": self.brand,
            "price": self.price,
            "size": self.size,
        }

dolls = []

d1 = Doll(1, "Marvel", "$8.90", "50cm")
d2 = Doll(2, "Hasbro", "$10", "25cm")
d3 = Doll(3, "Barbie", "$12", "30cm")

dolls.append(d1.to_dict())
dolls.append(d2.to_dict())
dolls.append(d3.to_dict())


with open("dolls.json", "w") as file:
    json.dump(dolls, file, indent=4)

print("Data written to dolls.json")

with open("dolls.json", "r") as file:
    data = json.load(file)

print("Reading dolls from JSON file...")

for doll in data:
    print("Id:", doll["id"])
    print("Brand:", doll["brand"])
    print("Price:", doll["price"])
    print("Size:", doll["size"])
