class ChickenCoop:
    pass