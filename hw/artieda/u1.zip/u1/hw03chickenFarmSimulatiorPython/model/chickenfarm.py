class ChickenFarm:
    pass