class Egg:
    pass