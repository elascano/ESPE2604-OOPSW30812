class Poop:
    pass