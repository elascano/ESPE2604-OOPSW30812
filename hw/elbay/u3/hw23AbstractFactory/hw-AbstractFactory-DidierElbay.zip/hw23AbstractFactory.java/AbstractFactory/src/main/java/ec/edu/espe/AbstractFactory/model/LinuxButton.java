
package ec.edu.espe.AbstractFactory.model;

/**
 *
 * @author Didier Elbay
 */
public class LinuxButton extends Button {
    @Override
    public String paint() {
        return "I'm a LinuxButton: " + caption;
    }
}
