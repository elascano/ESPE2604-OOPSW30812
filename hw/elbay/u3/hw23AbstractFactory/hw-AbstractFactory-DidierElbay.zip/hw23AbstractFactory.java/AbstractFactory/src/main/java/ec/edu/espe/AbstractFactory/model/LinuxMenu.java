
package ec.edu.espe.AbstractFactory.model;

/**
 *
 * @author Didier Elbay
 */
public class LinuxMenu extends Menu {
    @Override
    public String paint() {
        return "I'm a LinuxMenu: " + caption;
    }
}
