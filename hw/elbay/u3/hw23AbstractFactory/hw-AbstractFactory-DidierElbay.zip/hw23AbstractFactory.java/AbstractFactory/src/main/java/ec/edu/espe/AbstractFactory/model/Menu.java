
package ec.edu.espe.AbstractFactory.model;

/**
 *
 * @author Didier Elbay
 */
public abstract class Menu {
    public String caption;
    public abstract String paint();
}
