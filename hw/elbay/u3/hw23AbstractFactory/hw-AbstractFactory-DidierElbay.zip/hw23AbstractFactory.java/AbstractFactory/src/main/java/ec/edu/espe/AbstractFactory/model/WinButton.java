
package ec.edu.espe.AbstractFactory.model;

/**
 *
 * @author Didier Elbay
 */
public class WinButton extends Button {
    @Override
    public String paint() {
        return "I'm a WinButton: " + caption;
    }
}
