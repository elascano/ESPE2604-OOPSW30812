
package ec.edu.espe.AbstractFactory.model;

/**
 *
 * @author Didier Elbay
 */
public class WinMenu extends Menu {
    @Override
    public String paint() {
        return "I'm a WinMenu: " + caption;
    }
}
