/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ec.edu.espe.oopconceptsfarm.model;

/**
 *
 * @author Adrian Vizcaino <The-Softwarriors at ESPE>
 */
import java.util.Date;

public class Sheep extends FarmAnimal {

    private Date lastSheering;
    private String woolQuality;

    public Sheep(int id,
            String breed,
            Date bornOn,
            float weight,
            String healthStatus,
            Date lastSheering,
            String woolQuality) {

        super(id, breed, bornOn, weight, healthStatus);

        this.lastSheering = lastSheering;
        this.woolQuality = woolQuality;
    }

    public void shear() {
        lastSheering = new Date();
    }
}
