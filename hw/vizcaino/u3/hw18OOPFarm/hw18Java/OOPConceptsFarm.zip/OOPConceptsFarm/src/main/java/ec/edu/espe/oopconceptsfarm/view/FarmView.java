/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ec.edu.espe.oopconceptsfarm.view;

/**
 *
 * @author Adrian Vizcaino <The-Softwarriors at ESPE>
 */
import ec.edu.espe.oopconceptsfarm.controller.FarmController;
import ec.edu.espe.oopconceptsfarm.model.*;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.Date;

public class FarmView extends JFrame {

    private JTable tblAnimals;
    private FarmController controller;

    public FarmView(FarmController controller) {

        this.controller = controller;

        setTitle("Farm Management System");
        setSize(1000, 600);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        initializeComponents();
    }

    private void initializeComponents() {

        setLayout(new BorderLayout());

        JMenuBar menuBar = new JMenuBar();

        JMenu menuAnimals = new JMenu("Animals");
        JMenu menuActions = new JMenu("Actions");

        JMenuItem mnuAddPig = new JMenuItem("Add Pig");
        JMenuItem mnuAddCow = new JMenuItem("Add Cow");
        JMenuItem mnuAddChicken = new JMenuItem("Add Chicken");
        JMenuItem mnuAddSheep = new JMenuItem("Add Sheep");

        JMenuItem mnuFeedAnimal = new JMenuItem("Feed Animal");
        JMenuItem mnuLayEggs = new JMenuItem("Chicken - Lay Eggs");
        JMenuItem mnuMilkCow = new JMenuItem("Cow - Milk");
        JMenuItem mnuCutPig = new JMenuItem("Pig - Process Meat");
        JMenuItem mnuShearSheep = new JMenuItem("Sheep - Shear Wool");

        menuAnimals.add(mnuAddPig);
        menuAnimals.add(mnuAddCow);
        menuAnimals.add(mnuAddChicken);
        menuAnimals.add(mnuAddSheep);

        menuActions.add(mnuFeedAnimal);
        menuActions.addSeparator();
        menuActions.add(mnuLayEggs);
        menuActions.add(mnuMilkCow);
        menuActions.add(mnuCutPig);
        menuActions.add(mnuShearSheep);

        menuBar.add(menuAnimals);
        menuBar.add(menuActions);

        setJMenuBar(menuBar);

        tblAnimals = new JTable();

        add(new JScrollPane(tblAnimals), BorderLayout.CENTER);

        mnuAddPig.addActionListener(e -> addPig());

        mnuAddCow.addActionListener(e -> addCow());

        mnuAddChicken.addActionListener(e -> addChicken());

        mnuAddSheep.addActionListener(e -> addSheep());

        mnuFeedAnimal.addActionListener(e -> feedAnimal());

        mnuLayEggs.addActionListener(e -> layEggs());

        mnuMilkCow.addActionListener(e -> milkCow());

        mnuCutPig.addActionListener(e -> cutPig());

        mnuShearSheep.addActionListener(e -> shearSheep());

        refreshTable();
    }

    private void addPig() {

        try {

            int id = Integer.parseInt(
                    JOptionPane.showInputDialog(this, "Pig ID"));

            String breed =
                    JOptionPane.showInputDialog(this, "Breed");

            float weight = Float.parseFloat(
                    JOptionPane.showInputDialog(this, "Weight"));

            Pig pig = new Pig(
                    id,
                    breed,
                    new Date(),
                    weight,
                    "Healthy",
                    100.0f,
                    1);

            controller.addAnimal(pig);

            refreshTable();

        } catch (Exception ex) {

            JOptionPane.showMessageDialog(
                    this,
                    "Invalid data");
        }
    }

    private void addCow() {

        try {

            int id = Integer.parseInt(
                    JOptionPane.showInputDialog(this, "Cow ID"));

            String breed =
                    JOptionPane.showInputDialog(this, "Breed");

            float weight = Float.parseFloat(
                    JOptionPane.showInputDialog(this, "Weight"));

            Cow cow = new Cow(
                    id,
                    breed,
                    new Date(),
                    weight,
                    "Healthy",
                    true,
                    15.0f);

            controller.addAnimal(cow);

            refreshTable();

        } catch (Exception ex) {

            JOptionPane.showMessageDialog(
                    this,
                    "Invalid data");
        }
    }

    private void addChicken() {

        try {

            int id = Integer.parseInt(
                    JOptionPane.showInputDialog(this, "Chicken ID"));

            String breed =
                    JOptionPane.showInputDialog(this, "Breed");

            float weight = Float.parseFloat(
                    JOptionPane.showInputDialog(this, "Weight"));

            Chicken chicken = new Chicken(
                    id,
                    breed,
                    new Date(),
                    weight,
                    "Healthy",
                    false,
                    7,
                    "White");

            controller.addAnimal(chicken);

            refreshTable();

        } catch (Exception ex) {

            JOptionPane.showMessageDialog(
                    this,
                    "Invalid data");
        }
    }

    private void addSheep() {

        try {

            int id = Integer.parseInt(
                    JOptionPane.showInputDialog(this, "Sheep ID"));

            String breed =
                    JOptionPane.showInputDialog(this, "Breed");

            float weight = Float.parseFloat(
                    JOptionPane.showInputDialog(this, "Weight"));

            Sheep sheep = new Sheep(
                    id,
                    breed,
                    new Date(),
                    weight,
                    "Healthy",
                    new Date(),
                    "High");

            controller.addAnimal(sheep);

            refreshTable();

        } catch (Exception ex) {

            JOptionPane.showMessageDialog(
                    this,
                    "Invalid data");
        }
    }

    private void feedAnimal() {

        try {

            int id = Integer.parseInt(
                    JOptionPane.showInputDialog(this, "Animal ID"));

            String foodDescription =
                    JOptionPane.showInputDialog(this, "Food");

            Food food =
                    new Food(1, foodDescription);

            controller.feedAnimal(id, food);

            refreshTable();

            JOptionPane.showMessageDialog(
                    this,
                    "Animal fed successfully");

        } catch (Exception ex) {

            JOptionPane.showMessageDialog(
                    this,
                    "Operation failed");
        }
    }

    private void layEggs() {

        JOptionPane.showMessageDialog(
                this,
                "Chicken laid eggs");
    }

    private void milkCow() {

        JOptionPane.showMessageDialog(
                this,
                "Cow milk production executed");
    }

    private void cutPig() {

        JOptionPane.showMessageDialog(
                this,
                "Pig meat processing executed");
    }

    private void shearSheep() {

        JOptionPane.showMessageDialog(
                this,
                "Sheep shearing executed");
    }

    private void refreshTable() {

        DefaultTableModel model =
                new DefaultTableModel();

        model.addColumn("ID");
        model.addColumn("Type");
        model.addColumn("Breed");
        model.addColumn("Weight");
        model.addColumn("Age (Months)");

        for (FarmAnimal animal :
                controller.getAnimals()) {

            model.addRow(new Object[]{
                    animal.getId(),
                    animal.getClass().getSimpleName(),
                    animal.getBreed(),
                    animal.getWeight(),
                    animal.getAgeInMonths()
            });
        }

        tblAnimals.setModel(model);
    }
}