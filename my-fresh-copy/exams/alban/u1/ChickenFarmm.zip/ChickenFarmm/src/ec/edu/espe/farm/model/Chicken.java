package ec.edu.espe.farm.model;

public class Chicken {
    int id;
    String name;
    String color;
    int age;

    public Chicken(int id, String name, String color, int age) {
        this.id = id;
        this.name = name;
        this.color = color;
        this.age = age;
    }

    @Override
    public String toString() {
        return "Chicken{" + "id=" + id + ", name=" + name + ", color=" + color + ", age=" + age + '}';
    }
}