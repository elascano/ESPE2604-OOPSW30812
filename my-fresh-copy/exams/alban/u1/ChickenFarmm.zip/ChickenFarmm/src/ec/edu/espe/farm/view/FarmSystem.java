package ec.edu.espe.farm.view;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import ec.edu.espe.farm.model.Chicken;
import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;

public class FarmSystem {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        ArrayList<Chicken> chickens = new ArrayList<>();
        Gson gson = new Gson();
        
        int id;
        String name;
        String color;
        int age;
        
        System.out.println("--- Ingrese datos del pollo ---");
        System.out.print("ID: "); id = sc.nextInt();
        System.out.print("Nombre: "); name = sc.next();
        System.out.print("Color: "); color = sc.next();
        System.out.print("Edad: "); age = sc.nextInt();

        Chicken newChicken = new Chicken(id, name, color, age);
        chickens.add(newChicken);

        try (FileWriter writer = new FileWriter("chickens.json")) {
            gson.toJson(chickens, writer);
            System.out.println("Datos guardados exitosamente.");
        } catch (IOException e) {
            e.printStackTrace();
        }

        System.out.println("\n--- Leyendo desde archivo JSON ---");
        try (Reader reader = new FileReader("chickens.json")) {
            ArrayList<Chicken> listFromFile = gson.fromJson(reader, 
                new TypeToken<ArrayList<Chicken>>(){}.getType());
            
            for (Chicken c : listFromFile) {
                System.out.println(c);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}