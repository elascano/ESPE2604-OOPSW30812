import csv
import json
import os

from model.vinyl import Vinyl

def save_in_json(vinyl):

    vinyls_data = []

    if os.path.exists("vinyls.json"):

        with open("vinyls.json", "r") as file:

            try:
                vinyls_data = json.load(file)

            except json.JSONDecodeError:
                vinyls_data = []

    vinyls_data.append(vinyl.to_dict())

    with open("vinyls.json", "w") as file:

        json.dump(vinyls_data, file, indent=4)
        

def read_json():

    vinyls = []

    if not os.path.exists("vinyls.json"):
        return vinyls

    with open("vinyls.json", "r") as file:

        data = json.load(file)

        for item in data:

            vinyl = Vinyl(
                item["id"],
                item["title"],
                item["year"],
                item["genre"]
            )

            vinyls.append(vinyl)

    return vinyls