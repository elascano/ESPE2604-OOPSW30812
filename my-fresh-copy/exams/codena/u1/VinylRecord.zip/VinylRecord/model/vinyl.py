class Vinyl:

    def __init__(self, id, title, year, genre):
        self.id = id
        self.title = title
        self.year = year
        self.genre = genre

    def to_dict(self):
        return {
            "id": self.id,
            "title": self.title,
            "year": self.year,
            "genre": self.genre
        }

    def __str__(self):
        return (f"Vinyl("
                f"id={self.id}, "
                f"title={self.title}, "
                f"year={self.year}, "
                f"genre={self.genre})")