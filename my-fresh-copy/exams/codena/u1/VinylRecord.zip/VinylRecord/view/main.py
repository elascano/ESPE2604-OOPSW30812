from model.vinyl import Vinyl

from model.file_manager import (
    save_in_json,
    read_json,
)

running = True

while running:

    print("\n=== MENU ===")
    print("1. Add Vinyl")
    print("2. Show Vinyl")
    print("3. Exit")

    option = int(input("Choose an option: "))

    match option:

        case 1:

            print("\n--- ENTER DATA ---")

            s_id = int(input("ID: "))
            s_title = input("Title: ")
            s_year = int(input("Year: "))
            s_genre = input("Genre: ")

            vinyl = Vinyl(
                s_id,
                s_title,
                s_year,
                s_genre
            )

            save_in_json(vinyl)

            print("saved.")

        case 2:

            print("\n--- VINYLS JSON ---")

            vinyls = read_json()

            for vinyl in vinyls:
                print(vinyl)

        case 3:

            running = False

            print("Program finished.")

        case _:

            print("Invalid option.")