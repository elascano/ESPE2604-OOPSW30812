package edu.espe.ec.student;

import edu.espe.ec.student.controller.StudentController;
import edu.espe.ec.student.repository.JsonStudentRepository;
import edu.espe.ec.student.repository.StudentRepository;
import edu.espe.ec.student.view.StudentView;

public class Main {
    public static void main(String[] args) {
        StudentRepository repository = new JsonStudentRepository("students.json");
        StudentView view = new StudentView();
        StudentController controller = new StudentController(view, repository);
        
        controller.start();
    }
}
