package edu.espe.ec.student.controller;

import edu.espe.ec.student.model.Student;
import edu.espe.ec.student.repository.StudentRepository;
import edu.espe.ec.student.view.StudentView;

import java.util.List;

public class StudentController {
    private final StudentView view;
    private final StudentRepository repository;

    public StudentController(StudentView view, StudentRepository repository) {
        this.view = view;
        this.repository = repository;
    }

    public void start() {
        boolean exit = false;
        while (!exit) {
            view.showMenu();
            int choice = view.getMenuChoice();
            switch (choice) {
                case 1:
                    addStudent();
                    break;
                case 2:
                    listStudents();
                    break;
                case 3:
                    exit = true;
                    view.displayMessage("Exiting program...");
                    break;
                default:
                    view.displayMessage("Invalid choice. Try again.");
            }
        }
    }

    private void addStudent() {
        Student student = view.getStudentInput();
        List<Student> students = repository.findAll();
        students.add(student);
        repository.saveAll(students);
        view.displayMessage("Student added successfully!");
    }

    private void listStudents() {
        List<Student> students = repository.findAll();
        view.displayStudents(students);
    }
}
