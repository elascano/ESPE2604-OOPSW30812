package edu.espe.ec.student.view;

import edu.espe.ec.student.model.Student;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class StudentView {
    private final Scanner scanner;

    public StudentView() {
        this.scanner = new Scanner(System.in);
    }

    public void showMenu() {
        System.out.println("\n========================================");
        System.out.println("   STUDENT MANAGEMENT SYSTEM - ESPE");
        System.out.println("========================================");
        System.out.println("1. Add New Student");
        System.out.println("2. List All Students");
        System.out.println("3. Exit");
        System.out.println("----------------------------------------");
        System.out.print("Select an option: ");
    }

    public int getMenuChoice() {
        try {
            return Integer.parseInt(scanner.nextLine());
        } catch (NumberFormatException e) {
            return -1;
        }
    }

    public Student getStudentInput() {
        System.out.println("\n--- Entering New Student Data ---");
        System.out.print("ID: ");
        String id = scanner.nextLine();
        System.out.print("First Name: ");
        String firstName = scanner.nextLine();
        System.out.print("Last Name: ");
        String lastName = scanner.nextLine();
        System.out.print("Address: ");
        String address = scanner.nextLine();
        System.out.print("Email: ");
        String email = scanner.nextLine();

        List<Double> grades = new ArrayList<>();
        System.out.println("Enter grades (type 'done' to finish):");
        while (true) {
            System.out.print("  > Grade: ");
            String input = scanner.nextLine();
            if (input.equalsIgnoreCase("done")) {
                break;
            }
            try {
                double grade = Double.parseDouble(input);
                grades.add(grade);
            } catch (NumberFormatException e) {
                System.out.println("    [!] Invalid input. Enter a number or 'done'.");
            }
        }

        return new Student(id, firstName, lastName, address, email, grades);
    }

    public void displayStudents(List<Student> students) {
        if (students.isEmpty()) {
            System.out.println("\n[!] No students found in the system.");
        } else {
            System.out.println("\n" + "=".repeat(120));
            System.out.printf("%-10s | %-25s | %-25s | %-25s | %-8s%n", 
                              "ID", "FULL NAME", "EMAIL", "ADDRESS", "AVERAGE");
            System.out.println("-".repeat(120));
            
            for (Student student : students) {
                String fullName = student.getFirstName() + " " + student.getLastName();
                System.out.printf("%-10s | %-25s | %-25s | %-25s | %-8.2f%n", 
                                  student.getId(), 
                                  truncate(fullName, 25), 
                                  truncate(student.getEmail(), 25), 
                                  truncate(student.getAddress(), 25), 
                                  student.getAverage());
            }
            System.out.println("=".repeat(120));
            System.out.printf("Total students: %d%n", students.size());
        }
    }

    private String truncate(String text, int maxLength) {
        if (text == null) return "";
        return (text.length() <= maxLength) ? text : text.substring(0, maxLength - 3) + "...";
    }

    public void displayMessage(String message) {
        System.out.println("\n>>> " + message);
    }
}
