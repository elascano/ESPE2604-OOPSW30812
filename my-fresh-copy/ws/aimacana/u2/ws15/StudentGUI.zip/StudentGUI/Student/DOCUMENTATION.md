# Student Management System Documentation

## 1. Requirements

### Functional Requirements
- **FR1: Student Registration:** The system shall allow users to enter student details (ID, First Name, Last Name, Address, Email).
- **FR2: Grade Management:** The system shall allow adding multiple numeric grades to a student during registration.
- **FR3: Automatic Calculation:** The system shall automatically calculate the average grade for each student.
- **FR4: Persistence:** The system shall save student data to a JSON file and load it upon startup.
- **FR5: Data Display:** The system shall display a list of all registered students and their calculated averages in a tabular format.
- **FR6: Input Validation:** The system shall validate that mandatory fields are not empty and that grades are within a valid range (0-20).

### Non-Functional Requirements
- **NFR1: Usability:** The user interface should be intuitive and follow standard GUI design principles.
- **NFR2: Reliability:** Data should be correctly persisted and retrieved without loss.
- **NFR3: Maintainability:** The code should follow clean architecture patterns (MVC) for easy modification.

## 2. Program Features
- **Centralized Data Management:** Uses a JSON repository for easy data portability.
- **Dynamic Table Updates:** The student list updates immediately after a new student is saved or deleted.
- **Responsive Layout:** Uses JavaFX layouts (`SplitPane`, `VBox`, `GridPane`, `BorderPane`) to adapt to different window sizes.
- **Real-time Validation:** Employs `TextFormatter` for strict numeric ID and grade range (0-20) control.
- **Advanced Search:** Includes a real-time search bar to filter students by ID, First Name, or Last Name.
- **Management Lifecycle:** Supports full CRUD operations (Create, Read, Delete) for student records.
- **Visual Status Indicators:** The student directory highlights passing/failing status based on calculated GPA.
- **Clean Separation of Concerns:** Logic is strictly separated between Model, View, Controller, and Repository layers.
