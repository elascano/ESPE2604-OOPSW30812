package edu.espe.ec.student.repository;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import edu.espe.ec.student.model.Student;

import java.io.*;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

public class JsonStudentRepository implements StudentRepository {
    private final String filePath;
    private final Gson gson;

    public JsonStudentRepository(String filePath) {
        this.filePath = filePath;
        this.gson = new GsonBuilder().setPrettyPrinting().create();
    }

    @Override
    public void saveAll(List<Student> students) {
        try (Writer writer = new FileWriter(filePath)) {
            gson.toJson(students, writer);
        } catch (IOException e) {
            System.err.println("Error saving students to JSON: " + e.getMessage());
        }
    }

    @Override
    public List<Student> findAll() {
        File file = new File(filePath);
        if (!file.exists()) {
            return new ArrayList<>();
        }

        try (Reader reader = new FileReader(filePath)) {
            Type listType = new TypeToken<ArrayList<Student>>() {}.getType();
            List<Student> students = gson.fromJson(reader, listType);
            
            if (students == null) {
                return new ArrayList<>();
            }

            // Recalculate average for each student after reading from JSON
            for (Student student : students) {
                student.calculateAverage();
            }
            
            return students;
        } catch (IOException e) {
            System.err.println("Error reading students from JSON: " + e.getMessage());
            return new ArrayList<>();
        }
    }

    @Override
    public void deleteById(String id) {
        List<Student> students = findAll();
        students.removeIf(student -> student.getId().equals(id));
        saveAll(students);
    }
}
