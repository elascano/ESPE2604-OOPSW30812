package edu.espe.ec.student.repository;

import edu.espe.ec.student.model.Student;
import java.util.List;

public interface StudentRepository {
    void saveAll(List<Student> students);
    List<Student> findAll();
    void deleteById(String id);
}
