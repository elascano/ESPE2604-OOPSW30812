package edu.espe.ec.student.view;

import edu.espe.ec.student.controller.StudentController;
import edu.espe.ec.student.model.Student;
import edu.espe.ec.student.repository.JsonStudentRepository;
import edu.espe.ec.student.repository.StudentRepository;
import javafx.application.Application;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.effect.DropShadow;

import java.util.ArrayList;
import java.util.List;
import java.util.function.UnaryOperator;

public class StudentFxView extends Application {
    private StudentController controller;
    private ObservableList<Student> studentList;
    private ObservableList<Double> currentGrades;

    private TextField idField;
    private TextField firstNameField;
    private TextField lastNameField;
    private TextField addressField;
    private TextField emailField;
    private TextField gradeField;
    private TextField searchField;
    private ListView<Double> gradesListView;
    private TableView<Student> studentTableView;
    private Button saveButton;
    
    // Stats Labels
    private Label totalStudentsLbl;
    private Label courseAvgLbl;
    private Label passCountLbl;
    private Label failCountLbl;
    
    // Chart
    private BarChart<String, Number> performanceChart;

    // Styles
    private static final String PRIMARY_COLOR = "#2c3e50";
    private static final String SECONDARY_COLOR = "#34495e";
    private static final String ACCENT_COLOR = "#3498db";
    private static final String SUCCESS_COLOR = "#27ae60";
    private static final String WARNING_COLOR = "#f39c12";
    private static final String ERROR_COLOR = "#e74c3c";
    private static final String TEXT_LIGHT = "#ecf0f1";

    @Override
    public void start(Stage primaryStage) {
        StudentRepository repository = new JsonStudentRepository("students.json");
        this.controller = new StudentController(repository);
        this.studentList = FXCollections.observableArrayList(controller.getAllStudents());
        this.currentGrades = FXCollections.observableArrayList();

        primaryStage.setTitle("Student Management System Pro v3.0");

        // --- Layout ---
        BorderPane mainLayout = new BorderPane();
        mainLayout.setTop(createHeaderAndStats());
        
        SplitPane splitPane = new SplitPane();
        splitPane.getItems().addAll(createForm(), createTableAndChart());
        splitPane.setDividerPositions(0.32);
        
        mainLayout.setCenter(splitPane);

        Scene scene = new Scene(mainLayout, 1250, 850);
        primaryStage.setScene(scene);
        updateDashboardStats();
        primaryStage.show();
    }

    private VBox createHeaderAndStats() {
        VBox topBox = new VBox();
        
        // Header
        HBox header = new HBox();
        header.setPadding(new Insets(15, 25, 15, 25));
        header.setAlignment(Pos.CENTER_LEFT);
        header.setStyle("-fx-background-color: " + PRIMARY_COLOR + ";");
        
        Label title = new Label("👤 ACADEMIC DASHBOARD");
        title.setStyle("-fx-text-fill: white; -fx-font-size: 22px; -fx-font-weight: bold;");
        
        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);
        
        Label sysInfo = new Label("Enterprise Edition v3.0");
        sysInfo.setStyle("-fx-text-fill: #bdc3c7; -fx-font-style: italic;");
        
        header.getChildren().addAll(title, spacer, sysInfo);

        // Stats Bar
        HBox statsBar = new HBox(20);
        statsBar.setPadding(new Insets(20, 25, 20, 25));
        statsBar.setStyle("-fx-background-color: #f8f9fa; -fx-border-color: #dcdde1; -fx-border-width: 0 0 1 0;");
        statsBar.setAlignment(Pos.CENTER);

        totalStudentsLbl = new Label("0");
        courseAvgLbl = new Label("0.00");
        passCountLbl = new Label("0");
        failCountLbl = new Label("0");

        statsBar.getChildren().addAll(
            createStatCard("TOTAL STUDENTS", totalStudentsLbl, ACCENT_COLOR),
            createStatCard("COURSE AVERAGE", courseAvgLbl, WARNING_COLOR),
            createStatCard("PASSED", passCountLbl, SUCCESS_COLOR),
            createStatCard("FAILED", failCountLbl, ERROR_COLOR)
        );

        topBox.getChildren().addAll(header, statsBar);
        return topBox;
    }

    private VBox createStatCard(String title, Label valueLbl, String color) {
        VBox card = new VBox(5);
        card.setPadding(new Insets(15));
        card.setPrefWidth(220);
        card.setAlignment(Pos.CENTER);
        card.setStyle("-fx-background-color: white; -fx-background-radius: 10; -fx-border-color: " + color + "; -fx-border-width: 0 0 4 0;");
        
        DropShadow ds = new DropShadow();
        ds.setOffsetY(2.0);
        ds.setColor(Color.color(0, 0, 0, 0.1));
        card.setEffect(ds);

        Label titleLbl = new Label(title);
        titleLbl.setStyle("-fx-font-size: 11px; -fx-font-weight: bold; -fx-text-fill: #7f8c8d;");
        
        valueLbl.setStyle("-fx-font-size: 24px; -fx-font-weight: bold; -fx-text-fill: " + PRIMARY_COLOR + ";");
        
        card.getChildren().addAll(titleLbl, valueLbl);
        return card;
    }

    private VBox createForm() {
        VBox box = new VBox(15);
        box.setPadding(new Insets(25));
        box.setStyle("-fx-background-color: #fdfdfd;");

        Label titleLabel = new Label("Registration Form");
        titleLabel.setStyle("-fx-font-size: 18px; -fx-font-weight: bold; -fx-text-fill: " + SECONDARY_COLOR + ";");

        GridPane grid = new GridPane();
        grid.setHgap(12);
        grid.setVgap(12);

        idField = createTextField("Student ID (e.g., L001)");
        firstNameField = createTextField("First Name");
        lastNameField = createTextField("Last Name");
        addressField = createTextField("Address");
        emailField = createTextField("Email Address");

        setupIdFormatter(idField);
        
        // Add real-time validation
        addValidation(idField, s -> s.matches("L[0-9]+"));
        addValidation(firstNameField, s -> !s.trim().isEmpty());
        addValidation(lastNameField, s -> !s.trim().isEmpty());
        addValidation(emailField, this::isValidEmail);

        grid.add(new Label("ID:"), 0, 0);
        grid.add(idField, 1, 0);
        grid.add(new Label("First Name:"), 0, 1);
        grid.add(firstNameField, 1, 1);
        grid.add(new Label("Last Name:"), 0, 2);
        grid.add(lastNameField, 1, 2);
        grid.add(new Label("Address:"), 0, 3);
        grid.add(addressField, 1, 3);
        grid.add(new Label("Email:"), 0, 4);
        grid.add(emailField, 1, 4);

        // Grades Section
        VBox gradesSection = new VBox(10);
        Label gradesLabel = new Label("Academic Grades");
        gradesLabel.setStyle("-fx-font-weight: bold;");
        
        HBox gradeInputBox = new HBox(10);
        gradeField = new TextField();
        gradeField.setPromptText("0-20");
        gradeField.setPrefWidth(80);
        setupGradeFormatter(gradeField);
        
        Button addGradeBtn = new Button("➕ Add");
        addGradeBtn.setStyle("-fx-background-color: " + ACCENT_COLOR + "; -fx-text-fill: white;");
        addGradeBtn.setOnAction(e -> addGrade());
        
        gradeInputBox.getChildren().addAll(gradeField, addGradeBtn);

        gradesListView = new ListView<>(currentGrades);
        gradesListView.setPrefHeight(150);
        setupGradesListView();

        gradesSection.getChildren().addAll(gradesLabel, gradeInputBox, gradesListView);

        // Buttons
        saveButton = new Button("💾 SAVE STUDENT");
        saveButton.setStyle("-fx-background-color: " + SUCCESS_COLOR + "; -fx-text-fill: white; -fx-font-weight: bold;");
        saveButton.setMaxWidth(Double.MAX_VALUE);
        saveButton.setPadding(new Insets(12));
        saveButton.setOnAction(e -> saveStudent());

        Button clearBtn = new Button("🔄 Clear Form");
        clearBtn.setStyle("-fx-background-color: transparent; -fx-text-fill: " + ERROR_COLOR + "; -fx-border-color: " + ERROR_COLOR + ";");
        clearBtn.setMaxWidth(Double.MAX_VALUE);
        clearBtn.setOnAction(e -> clearForm());

        box.getChildren().addAll(titleLabel, grid, gradesSection, new Separator(), saveButton, clearBtn);
        return box;
    }

    private VBox createTableAndChart() {
        VBox box = new VBox(20);
        box.setPadding(new Insets(25));
        box.setStyle("-fx-background-color: white;");

        // Search and Table
        VBox tableBox = new VBox(10);
        HBox searchBar = new HBox(10);
        searchBar.setAlignment(Pos.CENTER_LEFT);
        
        Label tableTitle = new Label("Student Directory");
        tableTitle.setStyle("-fx-font-size: 18px; -fx-font-weight: bold;");
        
        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);
        
        searchField = new TextField();
        searchField.setPromptText("🔍 Search by name or ID...");
        searchField.setPrefWidth(300);
        searchField.setStyle("-fx-background-radius: 20;");

        searchBar.getChildren().addAll(tableTitle, spacer, searchField);

        studentTableView = new TableView<>();
        studentTableView.setPlaceholder(new Label("No students found in the database."));
        setupTableColumns();
        setupTableSelection();
        
        tableBox.getChildren().addAll(searchBar, studentTableView);
        VBox.setVgrow(studentTableView, Priority.ALWAYS);

        // Chart Section
        VBox chartBox = new VBox(10);
        Label chartTitle = new Label("📊 Grade Distribution / Performance");
        chartTitle.setStyle("-fx-font-weight: bold; -fx-text-fill: " + SECONDARY_COLOR + ";");
        
        CategoryAxis xAxis = new CategoryAxis();
        NumberAxis yAxis = new NumberAxis(0, 20, 2);
        performanceChart = new BarChart<>(xAxis, yAxis);
        performanceChart.setPrefHeight(250);
        performanceChart.setLegendVisible(false);
        performanceChart.setAnimated(true);

        chartBox.getChildren().addAll(chartTitle, performanceChart);

        box.getChildren().addAll(tableBox, new Separator(), chartBox);
        return box;
    }

    private void setupGradesListView() {
        gradesListView.setCellFactory(lv -> new ListCell<Double>() {
            @Override
            protected void updateItem(Double grade, boolean empty) {
                super.updateItem(grade, empty);
                if (empty || grade == null) {
                    setText(null);
                    setGraphic(null);
                } else {
                    HBox hBox = new HBox(10);
                    hBox.setAlignment(Pos.CENTER_LEFT);
                    Label gradeLbl = new Label(String.format("Grade: %.2f", grade));
                    gradeLbl.setStyle("-fx-font-weight: bold;");
                    
                    Region spacer = new Region();
                    HBox.setHgrow(spacer, Priority.ALWAYS);
                    
                    Button delBtn = new Button("❌");
                    delBtn.setStyle("-fx-background-color: transparent; -fx-text-fill: " + ERROR_COLOR + "; -fx-padding: 0;");
                    delBtn.setOnAction(e -> currentGrades.remove(grade));
                    
                    hBox.getChildren().addAll(gradeLbl, spacer, delBtn);
                    setGraphic(hBox);
                }
            }
        });
    }

    private void addValidation(TextField field, java.util.function.Predicate<String> validator) {
        field.textProperty().addListener((obs, oldVal, newVal) -> {
            if (validator.test(newVal)) {
                field.setStyle("-fx-border-color: " + SUCCESS_COLOR + "; -fx-border-width: 0 0 2 0;");
            } else {
                field.setStyle("-fx-border-color: " + ERROR_COLOR + "; -fx-border-width: 0 0 2 0;");
            }
        });
    }

    private void updateDashboardStats() {
        if (studentList.isEmpty()) {
            totalStudentsLbl.setText("0");
            courseAvgLbl.setText("0.00");
            passCountLbl.setText("0");
            failCountLbl.setText("0");
            return;
        }

        int total = studentList.size();
        double sum = 0;
        int passed = 0;
        
        for (Student s : studentList) {
            sum += s.getAverage();
            if (s.getAverage() >= 14) passed++;
        }

        totalStudentsLbl.setText(String.valueOf(total));
        courseAvgLbl.setText(String.format("%.2f", sum / total));
        passCountLbl.setText(String.valueOf(passed));
        failCountLbl.setText(String.valueOf(total - passed));
    }

    private void updateChart(Student student) {
        performanceChart.getData().clear();
        XYChart.Series<String, Number> series = new XYChart.Series<>();
        
        List<Double> grades = student.getGrades();
        for (int i = 0; i < grades.size(); i++) {
            series.getData().add(new XYChart.Data<>("Test " + (i + 1), grades.get(i)));
        }
        
        performanceChart.getData().add(series);
    }

    private void setupTableSelection() {
        studentTableView.getSelectionModel().selectedItemProperty().addListener((obs, oldSelection, newSelection) -> {
            if (newSelection != null) {
                populateFormWithStudent(newSelection);
                updateChart(newSelection);
            }
        });
        
        // Search logic
        FilteredList<Student> filteredData = new FilteredList<>(studentList, p -> true);
        searchField.textProperty().addListener((observable, oldValue, newValue) -> {
            filteredData.setPredicate(student -> {
                if (newValue == null || newValue.isEmpty()) return true;
                String lowerCaseFilter = newValue.toLowerCase();
                return student.getId().toLowerCase().contains(lowerCaseFilter) ||
                       student.getFirstName().toLowerCase().contains(lowerCaseFilter) ||
                       student.getLastName().toLowerCase().contains(lowerCaseFilter);
            });
        });
        SortedList<Student> sortedData = new SortedList<>(filteredData);
        sortedData.comparatorProperty().bind(studentTableView.comparatorProperty());
        studentTableView.setItems(sortedData);
    }

    private void setupTableColumns() {
        TableColumn<Student, String> idCol = new TableColumn<>("ID");
        idCol.setCellValueFactory(new PropertyValueFactory<>("id"));
        
        TableColumn<Student, String> nameCol = new TableColumn<>("Name");
        nameCol.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getFirstName() + " " + c.getValue().getLastName()));
        
        TableColumn<Student, String> avgCol = new TableColumn<>("GPA");
        avgCol.setCellValueFactory(c -> new SimpleStringProperty(String.format("%.2f", c.getValue().getAverage())));
        
        TableColumn<Student, String> statusCol = new TableColumn<>("Status");
        statusCol.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getAverage() >= 14 ? "PASS" : "FAIL"));
        statusCol.setCellFactory(col -> new TableCell<Student, String>() {
            @Override
            protected void updateItem(String item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) {
                    setText(null);
                    setStyle("");
                } else {
                    setText(item);
                    setStyle("-fx-font-weight: bold; -fx-text-fill: " + (item.equals("PASS") ? SUCCESS_COLOR : ERROR_COLOR) + ";");
                }
            }
        });

        studentTableView.getColumns().addAll(idCol, nameCol, avgCol, statusCol);
        studentTableView.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
        
        ContextMenu menu = new ContextMenu();
        MenuItem deleteItem = new MenuItem("🗑️ Delete Student");
        deleteItem.setOnAction(e -> confirmAndDeleteStudent(studentTableView.getSelectionModel().getSelectedItem()));
        menu.getItems().add(deleteItem);
        studentTableView.setContextMenu(menu);
    }

    private void setupIdFormatter(TextField field) {
        UnaryOperator<TextFormatter.Change> filter = change -> {
            String newText = change.getControlNewText();
            if (newText.isEmpty()) return change;
            if (newText.matches("L[0-9]*")) {
                return change;
            } else if (newText.equalsIgnoreCase("L")) {
                change.setText("L");
                return change;
            }
            return null;
        };
        field.setTextFormatter(new TextFormatter<>(filter));
        field.setText("L");
    }

    private void populateFormWithStudent(Student student) {
        idField.setText(student.getId());
        firstNameField.setText(student.getFirstName());
        lastNameField.setText(student.getLastName());
        addressField.setText(student.getAddress());
        emailField.setText(student.getEmail());
        currentGrades.setAll(student.getGrades());
    }

    private void setupGradeFormatter(TextField field) {
        UnaryOperator<TextFormatter.Change> filter = change -> {
            String newText = change.getControlNewText();
            if (newText.isEmpty()) return change;
            try {
                double val = Double.parseDouble(newText);
                if (val >= 0 && val <= 20) return change;
            } catch (NumberFormatException e) { }
            return null;
        };
        field.setTextFormatter(new TextFormatter<>(filter));
    }

    private void addGrade() {
        if (!gradeField.getText().isEmpty()) {
            currentGrades.add(Double.parseDouble(gradeField.getText()));
            gradeField.clear();
        }
    }

    private void saveStudent() {
        if (!validateInput()) return;
        
        // Duplicate check
        if (studentList.stream().anyMatch(s -> s.getId().equals(idField.getText().trim()))) {
            showAlert(Alert.AlertType.ERROR, "Duplicate", "ID already exists.");
            return;
        }

        Student student = new Student(idField.getText().trim(), firstNameField.getText().trim(), 
                                      lastNameField.getText().trim(), addressField.getText().trim(), 
                                      emailField.getText().trim(), new ArrayList<>(currentGrades));
        
        controller.addStudent(student);
        studentList.setAll(controller.getAllStudents());
        updateDashboardStats();
        clearForm();
        showAlert(Alert.AlertType.INFORMATION, "Success", "Record saved.");
    }

    private boolean validateInput() {
        return !idField.getText().equals("L") && !firstNameField.getText().isEmpty() && isValidEmail(emailField.getText());
    }

    private boolean isValidEmail(String email) {
        return email.matches("^[A-Za-z0-9+_.-]+@(.+)$") || email.isEmpty();
    }

    private void clearForm() {
        idField.setText("L");
        firstNameField.clear();
        lastNameField.clear();
        addressField.clear();
        emailField.clear();
        currentGrades.clear();
        performanceChart.getData().clear();
        studentTableView.getSelectionModel().clearSelection();
    }

    private void confirmAndDeleteStudent(Student student) {
        if (student == null) return;
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION, "Delete " + student.getFirstName() + "?", ButtonType.YES, ButtonType.NO);
        alert.showAndWait().ifPresent(type -> {
            if (type == ButtonType.YES) {
                controller.deleteStudent(student.getId());
                studentList.setAll(controller.getAllStudents());
                updateDashboardStats();
                clearForm();
            }
        });
    }

    private void showAlert(Alert.AlertType type, String title, String content) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setContentText(content);
        alert.showAndWait();
    }

    private TextField createTextField(String prompt) {
        TextField f = new TextField();
        f.setPromptText(prompt);
        return f;
    }

    public static void main(String[] args) {
        launch(args);
    }
}
