package edu.espe.ec.student;

import edu.espe.ec.student.view.StudentFxView;
import javafx.application.Application;

public class Main {
    public static void main(String[] args) {
        Application.launch(StudentFxView.class, args);
    }
}
