package edu.espe.ec.student.controller;

import edu.espe.ec.student.model.Student;
import edu.espe.ec.student.repository.StudentRepository;

import java.util.List;

public class StudentController {
    private final StudentRepository repository;

    public StudentController(StudentRepository repository) {
        this.repository = repository;
    }

    public void addStudent(Student student) {
        List<Student> students = repository.findAll();
        students.add(student);
        repository.saveAll(students);
    }

    public List<Student> getAllStudents() {
        return repository.findAll();
    }
}
