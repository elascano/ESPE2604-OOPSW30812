package edu.espe.ec.student.model;

import java.util.ArrayList;
import java.util.List;

public class Student {
    private String id;
    private String firstName;
    private String lastName;
    private String address;
    private String email;
    private List<Double> grades;
    private transient double average;

    public Student(String id, String firstName, String lastName, String address, String email) {
        this.id = id;
        this.firstName = firstName;
        this.lastName = lastName;
        this.address = address;
        this.email = email;
        this.grades = new ArrayList<>();
    }

    public Student(String id, String firstName, String lastName, String address, String email, List<Double> grades) {
        this.id = id;
        this.firstName = firstName;
        this.lastName = lastName;
        this.address = address;
        this.email = email;
        this.grades = grades;
        calculateAverage();
    }

    // Getters and Setters
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getFirstName() { return firstName; }
    public void setFirstName(String firstName) { this.firstName = firstName; }

    public String getLastName() { return lastName; }
    public void setLastName(String lastName) { this.lastName = lastName; }

    public String getAddress() { return address; }
    public void setAddress(String address) { this.address = address; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public List<Double> getGrades() { return grades; }
    public void setGrades(List<Double> grades) {
        this.grades = grades;
        calculateAverage();
    }

    public void addGrade(double grade) {
        this.grades.add(grade);
        calculateAverage();
    }

    public double getAverage() { return average; }

    public void calculateAverage() {
        if (grades == null || grades.isEmpty()) {
            this.average = 0.0;
        } else {
            double sum = 0;
            for (double grade : grades) {
                sum += grade;
            }
            double rawAverage = sum / grades.size();
            this.average = Math.round(rawAverage * 100.0) / 100.0;
        }
    }

    @Override
    public String toString() {
        return "Student{" +
                "id='" + id + '\'' +
                ", name='" + firstName + " " + lastName + '\'' +
                ", address='" + address + '\'' +
                ", email='" + email + '\'' +
                ", grades=" + grades +
                ", average=" + String.format("%.2f", average) +
                '}';
    }
}
