package edu.espe.ec.student.view;

import edu.espe.ec.student.controller.StudentController;
import edu.espe.ec.student.model.Student;
import edu.espe.ec.student.repository.JsonStudentRepository;
import edu.espe.ec.student.repository.StudentRepository;
import javafx.application.Application;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.*;
import javafx.stage.Stage;

import java.util.ArrayList;
import java.util.List;

public class StudentFxView extends Application {
    private StudentController controller;
    private ObservableList<Student> studentList;
    private ObservableList<Double> currentGrades;

    private TextField idField;
    private TextField firstNameField;
    private TextField lastNameField;
    private TextField addressField;
    private TextField emailField;
    private TextField gradeField;
    private ListView<Double> gradesListView;
    private TableView<Student> studentTableView;

    @Override
    public void start(Stage primaryStage) {
        // Initialize Repository and Controller
        StudentRepository repository = new JsonStudentRepository("students.json");
        this.controller = new StudentController(repository);
        this.studentList = FXCollections.observableArrayList(controller.getAllStudents());
        this.currentGrades = FXCollections.observableArrayList();

        primaryStage.setTitle("Student Management System");

        // --- Left Side: Form ---
        VBox formBox = createForm();
        
        // --- Right Side: Table ---
        VBox tableBox = createTable();

        // --- Main Layout ---
        SplitPane splitPane = new SplitPane();
        splitPane.getItems().addAll(formBox, tableBox);
        splitPane.setDividerPositions(0.4);

        Scene scene = new Scene(splitPane, 900, 600);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private VBox createForm() {
        VBox box = new VBox(10);
        box.setPadding(new Insets(20));
        box.setStyle("-fx-background-color: #f4f4f4;");

        Label titleLabel = new Label("Register New Student");
        titleLabel.setStyle("-fx-font-size: 18px; -fx-font-weight: bold;");

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);

        idField = new TextField();
        firstNameField = new TextField();
        lastNameField = new TextField();
        addressField = new TextField();
        emailField = new TextField();

        grid.add(new Label("Student ID:"), 0, 0);
        grid.add(idField, 1, 0);
        grid.add(new Label("First Name:"), 0, 1);
        grid.add(firstNameField, 1, 1);
        grid.add(new Label("Last Name:"), 0, 2);
        grid.add(lastNameField, 1, 2);
        grid.add(new Label("Address:"), 0, 3);
        grid.add(addressField, 1, 3);
        grid.add(new Label("Email:"), 0, 4);
        grid.add(emailField, 1, 4);

        // Grades Section
        Label gradesLabel = new Label("Grades");
        gradesLabel.setStyle("-fx-font-weight: bold;");
        
        gradeField = new TextField();
        gradeField.setPromptText("Enter grade");
        Button addGradeButton = new Button("Add Grade");
        addGradeButton.setMaxWidth(Double.MAX_VALUE);
        addGradeButton.setOnAction(e -> addGrade());

        gradesListView = new ListView<>(currentGrades);
        gradesListView.setPrefHeight(100);

        Button saveButton = new Button("Save Student");
        saveButton.setStyle("-fx-background-color: #4CAF50; -fx-text-fill: white; -fx-font-weight: bold;");
        saveButton.setMaxWidth(Double.MAX_VALUE);
        saveButton.setPadding(new Insets(10));
        saveButton.setOnAction(e -> saveStudent());

        Button clearButton = new Button("Clear Form");
        clearButton.setMaxWidth(Double.MAX_VALUE);
        clearButton.setOnAction(e -> clearForm());

        box.getChildren().addAll(titleLabel, grid, gradesLabel, gradeField, addGradeButton, gradesListView, saveButton, clearButton);
        return box;
    }

    private VBox createTable() {
        VBox box = new VBox(10);
        box.setPadding(new Insets(20));

        Label titleLabel = new Label("Enrolled Students");
        titleLabel.setStyle("-fx-font-size: 18px; -fx-font-weight: bold;");

        studentTableView = new TableView<>(studentList);
        
        TableColumn<Student, String> idCol = new TableColumn<>("ID");
        idCol.setCellValueFactory(new PropertyValueFactory<>("id"));

        TableColumn<Student, String> nameCol = new TableColumn<>("Name");
        nameCol.setCellValueFactory(cellData -> {
            Student s = cellData.getValue();
            return new SimpleStringProperty(s.getFirstName() + " " + s.getLastName());
        });

        TableColumn<Student, String> emailCol = new TableColumn<>("Email");
        emailCol.setCellValueFactory(new PropertyValueFactory<>("email"));

        TableColumn<Student, String> addressCol = new TableColumn<>("Address");
        addressCol.setCellValueFactory(new PropertyValueFactory<>("address"));

        TableColumn<Student, String> avgCol = new TableColumn<>("Average");
        avgCol.setCellValueFactory(cellData -> {
            double avg = cellData.getValue().getAverage();
            return new SimpleStringProperty(String.format("%.2f", avg));
        });

        studentTableView.getColumns().addAll(idCol, nameCol, emailCol, addressCol, avgCol);
        studentTableView.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);

        box.getChildren().addAll(titleLabel, studentTableView);
        VBox.setVgrow(studentTableView, Priority.ALWAYS);
        return box;
    }

    private void addGrade() {
        String text = gradeField.getText();
        if (text != null && !text.isEmpty()) {
            try {
                double grade = Double.parseDouble(text);
                if (grade < 0 || grade > 20) { // Assuming 0-20 scale common in some regions, or just general validation
                     showAlert(Alert.AlertType.ERROR, "Invalid Grade", "Please enter a grade between 0 and 20.");
                     return;
                }
                currentGrades.add(grade);
                gradeField.clear();
            } catch (NumberFormatException e) {
                showAlert(Alert.AlertType.ERROR, "Invalid Input", "Please enter a valid numeric grade.");
            }
        }
    }

    private void saveStudent() {
        if (idField.getText().isEmpty() || firstNameField.getText().isEmpty() || lastNameField.getText().isEmpty()) {
            showAlert(Alert.AlertType.ERROR, "Missing Information", "ID, First Name, and Last Name are required.");
            return;
        }

        Student student = new Student(
                idField.getText(),
                firstNameField.getText(),
                lastNameField.getText(),
                addressField.getText(),
                emailField.getText(),
                new ArrayList<>(currentGrades)
        );

        controller.addStudent(student);
        studentList.setAll(controller.getAllStudents());
        clearForm();
        showAlert(Alert.AlertType.INFORMATION, "Success", "Student saved successfully!");
    }

    private void clearForm() {
        idField.clear();
        firstNameField.clear();
        lastNameField.clear();
        addressField.clear();
        emailField.clear();
        gradeField.clear();
        currentGrades.clear();
    }

    private void showAlert(Alert.AlertType type, String title, String content) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
